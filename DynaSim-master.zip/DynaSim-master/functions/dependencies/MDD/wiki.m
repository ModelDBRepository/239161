%% MDD Wiki:
% 
% The MDD wiki contains additional information.
%
% Found at: https://github.com/davestanley/MultiDimensionalDictionary/wiki
%
% Run line below to open link in your browser:
web('https://github.com/davestanley/MultiDimensionalDictionary/wiki','-browser')