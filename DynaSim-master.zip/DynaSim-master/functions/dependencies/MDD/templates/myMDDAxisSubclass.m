classdef myMDDAxisSubclass < MDDAxis
end