function weblinkCode = makeWeblinkCode(url)
weblinkCode = sprintf('web(''%s'')', url);
return
